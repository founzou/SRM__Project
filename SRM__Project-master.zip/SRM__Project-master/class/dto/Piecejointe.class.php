<?php
	/**
	 * Object represents table 'piecejointes'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Piecejointe{
		
		var $idPj;
		var $idRec;
		var $photoPj;
		var $emailPj;
		var $bcPj;
		var $blPj;
		var $riPj;
		var $autrePj;
		
	}
?>