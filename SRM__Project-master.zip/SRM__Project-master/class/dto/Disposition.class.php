<?php
	/**
	 * Object represents table 'disposition'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Disposition{
		
		var $idDisp;
		var $idRec;
		var $actionDisp;
		var $quiDisp;
		var $quandDisp;
		var $commDisp;
		
	}
?>