<?php
	/**
	 * Object represents table 'webmaster'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Webmaster{
		
		var $idAdmin;
		var $admIdAdmin;
		var $nomWm;
		var $prenomWm;
		var $emailWm;
		var $mdpWm;
		var $telWm;
		
	}
?>