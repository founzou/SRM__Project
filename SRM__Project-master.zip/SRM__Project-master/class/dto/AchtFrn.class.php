<?php
	/**
	 * Object represents table 'acht_frn'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class AchtFrn{
		
		var $idAcht;
		var $idFrn;
		var $dateAchtFrn;
		var $type;
		
	}
?>