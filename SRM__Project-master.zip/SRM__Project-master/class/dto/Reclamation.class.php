<?php
	/**
	 * Object represents table 'reclamation'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Reclamation{
		
		var $idRec;
		var $idAdmin;
		var $idAcht;
		var $idFrn;
		var $ncmdRec;
		var $contactRec;
		var $dateRec;
		var $dateRepRec;
		var $descriptionRec;
		var $etatRec;
		
	}
?>