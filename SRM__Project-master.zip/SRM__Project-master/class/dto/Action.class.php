<?php
	/**
	 * Object represents table 'action'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Action{
		
		var $idAct;
		var $idRec;
		var $actionAct;
		var $quiAct;
		var $quandAct;
		var $commAct;
		
	}
?>