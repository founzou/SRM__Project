<?php
	/**
	 * Object represents table 'attreav'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Attreav{
		
		var $idAttrEav;
		var $idEav;
		var $domaineEav;
		var $poidsEav;
		var $critereEav;
		var $indicateurEav;
		var $priseEav;
		var $importanceEav;
		var $ponderationEav;
		var $notationEav;
		var $noteEav;
		
	}
?>