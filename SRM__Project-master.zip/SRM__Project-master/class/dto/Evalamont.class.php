<?php
	/**
	 * Object represents table 'evalamont'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Evalamont{
		
		var $idEam;
		var $idAdmin;
		var $idAcht;
		var $idFrn;
		var $etatEam;
		var $dateEam;
		var $scoreEam;
		var $classeEam;
		
	}
?>