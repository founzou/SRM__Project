<?php
	/**
	 * Object represents table 'admin_admin'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class AdminAdmin{
		
		var $idAdmin;
		var $admIdAdmin;
		var $dateAdminAdmin;
		var $type;
		
	}
?>