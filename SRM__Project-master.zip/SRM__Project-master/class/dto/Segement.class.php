<?php
	/**
	 * Object represents table 'segement'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Segement{
		
		var $idSeg;
		var $idAdmin;
		var $idFa;
		var $nomSeg;
		
	}
?>