<?php
	/**
	 * Object represents table 'admin_fa'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class AdminFa{
		
		var $idAdmin;
		var $idFa;
		
	}
?>