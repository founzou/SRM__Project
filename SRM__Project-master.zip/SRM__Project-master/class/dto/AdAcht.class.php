<?php
	/**
	 * Object represents table 'ad_acht'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class AdAcht{
		
		var $idAdmin;
		var $idAcht;
		var $dateAdAcht;
		var $type;
		
	}
?>