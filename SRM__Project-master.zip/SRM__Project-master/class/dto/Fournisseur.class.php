<?php
	/**
	 * Object represents table 'fournisseur'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Fournisseur{
		
		var $idFrn;
		var $nomFrn;
		var $prenomFrn;
		var $emailFrn;
		var $mdpFrn;
		var $telFrn;
		var $etatFrn;
		
	}
?>