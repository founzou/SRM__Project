<?php
	/**
	 * Object represents table 'rfi'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Rfi{
		
		var $idRfi;
		var $idFrn;
		var $rfiRemp;
		var $organRfi;
		var $pfRfi;
		var $bilanRfi;
		
	}
?>