<?php
	/**
	 * Object represents table 'objets'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Objet{
		
		var $idObj;
		var $idRec;
		var $retardObj;
		var $qteNCObj;
		var $qltNCObj;
		var $autreObj;
		
	}
?>