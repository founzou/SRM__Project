<?php
	/**
	 * Object represents table 'familleachat'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Familleachat{
		
		var $idFa;
		var $nomFa;
		var $codeFa;
		var $typeFa;
		var $serviceFa;
		var $classeFa;
		var $levierFa;
		
	}
?>