<?php
	/**
	 * Object represents table 'evalaval'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Evalaval{
		
		var $idEav;
		var $idAdmin;
		var $idAcht;
		var $idFrn;
		var $etatEav;
		var $dateEav;
		var $scoreEav;
		var $classeEav;
		
	}
?>