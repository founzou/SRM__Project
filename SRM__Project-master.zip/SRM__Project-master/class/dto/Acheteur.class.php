<?php
	/**
	 * Object represents table 'acheteur'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Acheteur{
		
		var $idAcht;
		var $nomAcht;
		var $prenomAcht;
		var $emailAcht;
		var $mdpAcht;
		var $telAcht;
		var $etatAcht;
		
	}
?>