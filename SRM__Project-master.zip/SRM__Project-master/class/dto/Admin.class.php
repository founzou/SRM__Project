<?php
	/**
	 * Object represents table 'admin'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Admin{
		
		var $idAdmin;
		var $nomAdmin;
		var $prenomAdmin;
		var $emailAdmin;
		var $mdpAdmin;
		var $telAdmin;
		var $etatAdmin;
		
	}
?>