<?php
	/**
	 * Object represents table 'frn_seg'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class FrnSeg{
		
		var $idFrn;
		var $idSeg;
		
	}
?>