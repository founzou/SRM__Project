<?php
	/**
	 * Object represents table 'attream'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2019-05-04 16:44	 
	 */
	class Attream{
		
		var $idAttrEam;
		var $idEam;
		var $domaineEam;
		var $poidsEam;
		var $critereEam;
		var $indicateurEam;
		var $priseEam;
		var $importanceEam;
		var $ponderationEam;
		var $notationEam;
		var $noteEam;
		
	}
?>