<?php
/**
 * Class that operate on table 'acht_frn'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class AchtFrnMySqlExtDAO extends AchtFrnMySqlDAO{

	
}
?>