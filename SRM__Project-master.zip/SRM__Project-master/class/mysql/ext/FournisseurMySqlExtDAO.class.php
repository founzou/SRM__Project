<?php
/**
 * Class that operate on table 'fournisseur'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class FournisseurMySqlExtDAO extends FournisseurMySqlDAO{

	
}
?>