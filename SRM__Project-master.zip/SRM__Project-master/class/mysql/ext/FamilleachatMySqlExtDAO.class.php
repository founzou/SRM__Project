<?php
/**
 * Class that operate on table 'familleachat'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class FamilleachatMySqlExtDAO extends FamilleachatMySqlDAO{

	
}
?>