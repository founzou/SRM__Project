<?php
/**
 * Class that operate on table 'admin_admin'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class AdminAdminMySqlExtDAO extends AdminAdminMySqlDAO{

	
}
?>