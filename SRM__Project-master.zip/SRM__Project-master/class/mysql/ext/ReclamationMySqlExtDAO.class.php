<?php
/**
 * Class that operate on table 'reclamation'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class ReclamationMySqlExtDAO extends ReclamationMySqlDAO{

	
}
?>