<?php
/**
 * Class that operate on table 'attream'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class AttreamMySqlExtDAO extends AttreamMySqlDAO{

	
}
?>