<?php
/**
 * Class that operate on table 'rfi'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class RfiMySqlExtDAO extends RfiMySqlDAO{

	
}
?>