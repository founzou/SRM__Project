<?php
/**
 * Class that operate on table 'frn_seg'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class FrnSegMySqlExtDAO extends FrnSegMySqlDAO{

	
}
?>