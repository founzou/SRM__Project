<?php
/**
 * Class that operate on table 'admin_fa'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2019-05-04 16:44
 */
class AdminFaMySqlExtDAO extends AdminFaMySqlDAO{

	
}
?>