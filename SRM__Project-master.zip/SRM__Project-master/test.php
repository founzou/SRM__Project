<?php

//extract($_POST);


//echo '<img src="data:image/jpeg;base64,' . base64_encode(file_get_contents($_FILES['blPj']['tmp_name'])) . '"/>';

//print_r($_POST);

//print_r($_FILES);

echo $_POST['score_finale'];